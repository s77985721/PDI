from models.Carrito import Carrito
""""
4. Crear el controlador CarritoController con los siguientes métodos:

    `agregar_producto(carrito, código_producto)` 
    ` calcular_total(carrito, descuento=0)`
    `realizar_compra(carrito)`. (Actualiza el saldo del cliente, resta el stock de los productos, vacía el carrito, etc)
    `mostrar_factura(carrito)`
"""




class carritoController:

    def __init__(self,cliente):
        
        self.cliente = cliente
    
    def agregar_producto(carrito, cod_prod):

        if not cod_prod:
            return "¿a quien queres agregar payaso?"
        else:
            return cod_prod
    consulta = "SELECT * FROM carrito WHERE cod_prod = %s"
    cursor.execute(consulta, (cod_prod,))
    resultado = cursor.fetchone()

    if resultado:
        # Si el producto ya está en el carrito, incrementar la cantidad
        nueva_cantidad = resultado[0] + 1
        actualizacion = "UPDATE carrito SET cantidad = %s WHERE codigo_producto = %s"
        cursor.execute(actualizacion, (nueva_cantidad, codigo_producto))
    else:
        # Si el producto no está en el carrito, agregarlo con cantidad inicial 1
        insercion = "INSERT INTO carrito (codigo_producto, cantidad) VALUES (%s, %s)"
        cursor.execute(insercion, (codigo_producto, 1))
    


    
    