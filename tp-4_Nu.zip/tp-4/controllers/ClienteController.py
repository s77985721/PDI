from models.Cliente import Cliente
import re
from config.database import cursor,conn

regex = r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'

class clienteController:

    def nuevo(nombre,email,saldo=0):

        if not email or not nombre or not isinstance(email,str) or not isinstance(nombre,str) or not re.match(regex, email) or not isinstance(saldo,int):

            return "Datos no valido"

        else:

            miCliente = Cliente(nombre,email,saldo)

            miCliente.insertar()

            return "El cliente se cargo con exito"

    def actualizar(email, nombre=None, saldo=None):
        
        if not email or not nombre or not saldo:

            return"No actualizamos nada"
        
        else:

            miCliente = Cliente(nombre, email, saldo)

            miCliente.Actualizar()

            return"Se actualizo con exito"        

    @staticmethod
    def borrar(email):

        """
        Luego de comprobar los datos Borra un cliente
        """

        if not email or not isinstance(email,str) or not re.match(regex, email):

            return "No es un email"
        
        clientes = Cliente.obtener_todo()

        exist = False

        for cliente in clientes:

            if email == cliente[1]:

                exist = True

        if exist:

            Cliente.borrar(email)

            return "Se borro con exito"
        
        else:

            return "Compruebe el correo"
    
    @staticmethod
    def obtener(email):

        """
        Luego de comprobar los datos obtiene un cliente
        """

        if not email or not isinstance(email,str) or not re.match(regex, email):

            return "No es un email"
        
        clientes = Cliente.obtener_todo()

        exist = False

        for cliente in clientes:

            if email == cliente[1]:

                exist = True

        if exist:

            miCliente = Cliente.obtener_uno(email)
        
        else:

            return "Compruebe el correo"

        return miCliente
        

