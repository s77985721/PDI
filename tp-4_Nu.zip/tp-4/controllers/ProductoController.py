from models.Producto import Producto

class productoController:
    def nuevo(nombre, precio, stock,cod_prod = 0,): #preguntar 

        if not isinstance(cod_prod,int) or not nombre or not precio or not isinstance(stock,int):

            return "Datos no valido"

        else:

            miProducto = Producto(cod_prod,nombre,precio,stock)

            miProducto.insertar()

            return "El cliente se cargo con exito"
        
    def actualizar(cod_prod  , nombre=None  , precio=None  , stock=None):
        if not cod_prod:

            return"No actualizamos nada"
        
        else:

            miProducto = Producto(cod_prod,nombre,precio,stock)

            miProducto.actualizar()

            return"Se actualizo con exito"  


    def borrar(cod_prod):
        if not cod_prod or not isinstance(cod_prod,int):

            return "No es un codigo"
        
        productos = Producto.obtener_todo()

        exist = False

        for producto in productos:

            if cod_prod == producto[0]:

                exist = True

        if exist:

            Producto.borrar(cod_prod)

            return "Se borro con exito"
        
        else:

            return "Compruebe el codigo"
            