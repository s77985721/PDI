from models.Cliente import Cliente
from models.Producto import Producto
from config.database import cursor,conn


class Carrito:

    def __init__(self,cliente):

        if not cliente:

            raise Exception("[ERROR] El cliente tiene que ser identficado")
        
        self.carrito = []
        self.cliente = cliente

    def agregar_producto(self, cod_prod):

        if cod_prod.stock > 0:

            self.carrito.append(producto)
            
        else: 

            return f"No hay mas {producto.nombre}"
    consulta = "SELECT cantidad FROM carrito WHERE cod_prod = %s"
    cursor.execute(consulta, (cod_prod,))
    resultado = cursor.fetchone()

    if resultado:
        # Si el producto ya está en el carrito, incrementar la cantidad
            nueva_cantidad = resultado[0] + 1
            actualizacion = "UPDATE carrito SET cantidad = %s WHERE codigo_producto = %s"
            cursor.execute(actualizacion, (nueva_cantidad, codigo_producto))
    else:
        # Si el producto no está en el carrito, agregarlo con cantidad inicial 1
            insercion = "INSERT INTO carrito (codigo_producto, cantidad) VALUES (%s, %s)"
            cursor.execute(insercion, (codigo_producto, 1))
    

    def calcular_total(self, descuento = 0):
        
        total = 0

        for producto in self.carrito:

            total += producto.precio

        self.descuento = descuento * total

        total = total - (self.descuento/100)

        return total

    def realizar_compra(self, descuento):
        
        total = self.calcular_total(descuento)

        if total > self.cliente.saldo:

            raise ValueError("Saldo insuficiente")

        else:


            self.cliente.saldo -= total


            list = []

          
            for producto in self.carrito:

                list.append(producto.nombre)

            self.cliente.historial.append({

                "id": "x",
                "productos": list

            })

            self.carrito.clear()
    