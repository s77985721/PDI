from config.database import cursor,conn

class Cliente:


    def __init__(self,nombre,email,saldo ):

        if not nombre:

            raise Exception("[ERROR] El cliente tiene que tener un nombre")

        if not email:

            raise Exception("[ERROR] El cliente tiene que ser identificado")

        self.nombre = nombre
        self.email = email
        self.saldo = saldo
        self.historial = []

    def __str__(self):

        return f"Nombre: {self.nombre} Email: {self.email}"
    
    def insertar(self):

        # INSERT INTO tabla (campo1, campo2, campo3...) VALUES (a,b,c,d)
        query = f"INSERT INTO clientes (name, email, saldo) VALUES(%s,%s,%s)"
        var = (self.nombre,self.email,self.saldo)

        cursor.execute(query,var)
        conn.commit() 


    def Actualizar(self):

        if not self.nombre or not self.email or not self.saldo:

            raise ValueError("Papi no hay cliente")
        
        query = f"UPDATE clientes SET name=%s, email=%s, saldo=%s WHERE email=%s"

        hug = (self.nombre, self.email, self.saldo, self.email)

        cursor.execute(query,hug)
        conn.commit()
    
    @staticmethod
    def obtener_uno(email):
        if not email :
            return"no hay nada"
        else:
            query = f"SELECT * FROM clientes WHERE email = %s"

            var = (email,)  #la coma al final python declara la tupla 

            cursor.execute(query,var)

            variable = cursor.fetchone()

            return Cliente(variable[0],variable[1],variable[2])
    
    def obtener_todo():

        query = f"SELECT * FROM clientes"

        cursor.execute(query,)
        
        datos = cursor.fetchall()

        return datos

        #return Cliente(nombre=datos[0],email=datos[1], saldo=datos[2])    
    
    def borrar(email):

        """
        Borrar un cliente con su email
        """

        query = f"DELETE FROM clientes WHERE email = %s"

        var = (email,)  

        cursor.execute(query,var)
        conn.commit() 

