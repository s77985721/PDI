from config.database import cursor,conn

class Producto:

    def __init__(self,cod_prod,nombre,precio, stock = 0):

        if not nombre:

            raise Exception("[ERROR] El producto tiene que tener un nombre")
        
        if not cod_prod:

            raise Exception("[ERROR] El producto tiene que ser identificado")
        
        if not precio:

            raise Exception("[ERROR] El prodcuto tiene que tener un precio")
        
        self.cod_prod = cod_prod
        self.nombre = nombre
        self.precio = precio
        self.stock = stock

    def insertar(self):

        if not self.cod_prod or not self.nombre or not self.precio:

            raise ValueError("Papi no hay Producto")
        
        query = f"INSERT INTO productos (cod_prod, nombre, precio, stock) VALUES (%s, %s, %s, %s)"

        var = (self.cod_prod, self.nombre, self.precio, self.stock)

        cursor.execute(query, var)
        conn.commit()

    def actualizar(self):
        
        query = f"UPDATE productos SET nombre = %s, precio = %s, stock = %s WHERE cod_prod = %s"

        hug = (self.nombre,self.precio, self.stock,self.cod_prod)

        cursor.execute(query,hug)
        conn.commit()

    @staticmethod
    def obtener(cod_prod):
            
            query = f"SELECT * FROM productos WHERE cod_prod = %s"

            var = (cod_prod,)  #la coma al final python declara la tupla 

            cursor.execute(query,var)

            variable = cursor.fetchone()

            return Producto(variable[0],variable[1],variable[2])
    
    def obtener_todo():

        query = f"SELECT * FROM productos"

        cursor.execute(query,)
        
        datos = cursor.fetchall()

        return datos

    def __str__(self) -> str:
    
        return f"Nombre: {self.nombre} Precio: {self.precio}"
    
    
    def borrar(cod_prod):

        """
        Borrar un producto con su cod
        """

        query = f"DELETE FROM productos WHERE cod_prod = %s"

        var = (cod_prod,)  

        cursor.execute(query,var)
        conn.commit() 