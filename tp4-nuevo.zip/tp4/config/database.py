import mysql.connector

conn = mysql.connector.connect(

    host = "localhost",
    user = "sant",
    password = "123",
    database = "negocios"

)

cursor = conn.cursor()

clientes = "CREATE TABLE IF NOT EXISTS clientes(name VARCHAR(50), email VARCHAR(255),saldo INT,PRIMARY KEY(email))"
productos = "CREATE TABLE IF NOT EXISTS productos(cod_prod INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(255), precio INT,stock INT)"


cursor.execute(clientes)
cursor.execute(productos)