from models.Carrito import Carrito
from controllers.ProductoController import ProductoController
from controllers.ClienteController import ClienteController

class CarritoController:

    @staticmethod
    def agregar_producto(carrito,cod_prod):

        if not cod_prod or not isinstance(cod_prod, int) or not carrito or not isinstance(carrito, Carrito):

            return "Compruebe los campos"
        
        producto = ProductoController.obtener(cod_prod)

        if isinstance(producto, str):

            print(producto)

        else:

            car = carrito.agregar_producto(producto)

            if not isinstance(car,str):                

                return "Producto cargado exitosamente"
            
            
            else:

                return f"{car}"

        
    def calcular_total(carrito,descuento = 0):

        if not carrito or not isinstance(carrito, Carrito) or not isinstance(descuento, int):

            return "Compruebe los campos"
        
        compra = carrito.calcular_total(descuento)

        if isinstance(compra,str):

            return (compra)
        
        return compra

    def realizar_compra(carrito):

        if not carrito or not isinstance(carrito, Carrito):

            
            return "Compruebe los campos{carrito}"

        try: 

            cods_prods = []
            list = []

            print("*************************************")
            for producto in carrito.listaDeProductos:

                print(producto.stock)
            print("*************************************")

            for producto in carrito.listaDeProductos:

                cods_prods.append(producto.cod_prod)

            frecuencias = {}

            for cod in cods_prods:

                if cod in frecuencias:

                    frecuencias[cod] += 1

                else:

                    frecuencias[cod] = 1

            for cod, frecuencia in frecuencias.items():

                tupla = (cod,frecuencia)

                list.append(tupla)
            
            i = 0

            for producto in carrito.listaDeProductos:

                if producto.cod_prod in list[0]:

                    producto.stock = producto.stock - list[i][1]

                print(list[i])

                if i < (len(list) - 1):

                    i += 1

                ProductoController.actualizar(producto.cod_prod,producto.nombre,producto.precio,producto.stock)

            print("----------------------------------")
            for producto in carrito.listaDeProductos:

                print(producto.stock)
            print("----------------------------------")

            compra = carrito.realizarCompra(0)

            ClienteController.actualizar(carrito.cliente.email,carrito.cliente.nombre,carrito.cliente.saldo)
            

            return "Compra realizada con exito"

        except ValueError:

           return f"No se pudo realizar la compra"
        

    def mostrar_factura(carrito):
   
        print("======================================")
        print("              FACTURA                ")
        print("======================================")
        print(f"{'cod_prod':<20}{'nombre':<10}{'precio':<15}{'stock':<10}")
        print("--------------------------------------")

      
        total= 0.0

        cantidad = 1

    
        for item in carrito:
            cod_prod = item['cod_prod']
            nombre = item['nombre']
            precio = item['precio']
            total_producto = precio * cantidad

      
        print(f"{cod_prod}{precio}{nombre}{total_producto:}")

        
        total += total_producto

   
        print("--------------------------------------")
        print(f"{'Total'}")
        print("======================================")
    
        
    



        
        


        
    