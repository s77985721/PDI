from models.Cliente import Cliente
import re

regex = r'^[a-z0-9.-]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'

class ClienteController:

    @staticmethod
    def nuevo(email,nombre):

        """
        Luego de validar los datos crea un nuevo cliente
        """

        if not email or not nombre or not isinstance(email,str) or not isinstance(nombre,str) or not re.match(regex, email):

            return "Datos no valido"

        else:

            miCliente = Cliente(nombre,email)

            miCliente.insertar()

            return "El cliente se cargo con exito"

    @staticmethod
    def actualizar(email, nombre=None, saldo=None):

        """
        Luego de validar los datos actualiza los datos del cliente
        """
        
        if not email or not isinstance(email,str) or not re.match(regex, email):

            return "No es un email"
        
        clientes = Cliente.obtener_todo()

        exist = False

        for cliente in clientes:

            if email == cliente.email:

                exist = True

        if exist:

            miCliente = Cliente(nombre, email, saldo)

            miCliente.Actualizar()

            return "Se Actualiza con exito"
        
        else:

            return "Compruebe el correo"
    @staticmethod
    def borrar(email):

        """
        Luego de comprobar los datos Borra un cliente
        """

        if not email or not isinstance(email,str) or not re.match(regex, email):

            return "No es un email"
        
        clientes = Cliente.obtener_todo()

        exist = False

        for cliente in clientes:

            if email == cliente[1]:

                exist = True

        if exist:

            Cliente.borrar(email)

            return "Se borro con exito"
        
        else:

            return "Compruebe el correo"
        
    @staticmethod
    def obtener(email):

        """
        Luego de comprobar los datos obtiene un cliente
        """

        if not email or not isinstance(email,str) or not re.match(regex, email):

            return "No es un email"
        
        clientes = Cliente.obtener_todo()

        exist = False

        for cliente in clientes:

            if email == cliente.email:

                exist = True

        if exist:

            miCliente = Cliente.obtener_uno(email)
        
        else:

            return "Compruebe el correo"

        return miCliente
        