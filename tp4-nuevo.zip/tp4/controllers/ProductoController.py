from models.Producto import Producto

class ProductoController:

    @staticmethod
    def nuevo(nombre,precio,stock):

        """
        Verifica los datos y agrega un producto a la base de datos
        """

        if not nombre or not precio or not stock or not isinstance(nombre,str) or not isinstance(precio,int) or not isinstance(stock,int):

            return "Campos incorrectos"
        
        producto = Producto(nombre,precio,stock)

        producto.insertar()

        return "Producto cargado exitosamente"

    @staticmethod
    def actualizar(cod_prod, nombre=None  , precio=None  , stock=None):

        """
        Comprueba los datos y actualiza un producto
        """

        if not cod_prod or not isinstance(cod_prod,int):

            return "No es un codigo"
        
        productos = Producto.obtener_todo()

        exist = False

        for producto in productos:

            if cod_prod == producto.cod_prod:

                exist = True

        if exist:

            prod = Producto(nombre, precio, stock, cod_prod)

            prod.actualizar()

            return "Se Actualizo con exito"
        
        else:

            return "Compruebe el codigo"
        

    @staticmethod
    def borrar(cod_prod):

        """
        Comprueba el codigo y borra un producto
        """

        if not cod_prod or not isinstance(cod_prod,int):

            return "No es un codigo"
        
        productos = Producto.obtener_todo()

        exist = False

        for producto in productos:

            if cod_prod == producto[0]:

                exist = True

        if exist:

            Producto.borrar(cod_prod)

            return "Se borro con exito"
        
        else:

            return "Compruebe el codigo"
        
    @staticmethod
    def obtener(cod_prod):

        """
        Verifica sea un codigo valido y devuelve una instancia producto
        """

        if not cod_prod or not isinstance(cod_prod,int):

            return "Codigo invalido"
        
        productos = Producto.obtener_todo()

        exist = False

        for producto in productos:

            if cod_prod == producto.cod_prod:

                exist = True

        if exist:

            prod = Producto.obtener(cod_prod)

            return prod
        
        else:

            return "Compruebe el codigo"