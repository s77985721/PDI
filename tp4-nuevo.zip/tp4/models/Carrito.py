from models.Cliente import Cliente
from models.Producto import Producto

class Carrito:

    def __init__(self,cliente):

        if not cliente:

            raise Exception("[ERROR] El cliente tiene que ser identficado")
        
        self.listaDeProductos = []
        self.cliente = cliente

    def agregar_producto(self, producto):

        if producto.stock > 0:

            self.listaDeProductos.append(producto)
            
        else: 

            return f"No hay mas {producto.nombre}"

    def calcular_total(self, descuento = 0):
        
        total = 0

        for producto in self.listaDeProductos:

            total += producto.precio

        self.descuento = descuento * total

        total = total - (self.descuento/100)

        return total

    def realizarCompra(self, descuento):
        
        total = self.calcular_total(descuento)

        if total > self.cliente.saldo:

            raise ValueError("Saldo insuficiente")

        else:

            self.cliente.saldo -= total

            list = []
          
            for producto in self.listaDeProductos:

                list.append(producto.nombre)

            self.cliente.historial.append({

                "id": "x",
                "productos": list

            })

            self.listaDeProductos.clear()