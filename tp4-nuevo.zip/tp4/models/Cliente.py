from config.database import cursor,conn

class Cliente:


    def __init__(self,nombre,email,saldo=0):

        if not nombre:

            raise Exception("[ERROR] El cliente tiene que tener un nombre")

        if not email:

            raise Exception("[ERROR] El cliente tiene que ser identificado")

        self.nombre = nombre
        self.email = email
        self.saldo = saldo
        self.historial = []

    def __repr__(self):

        return f"Nombre: {self.nombre} Email: {self.email} saldo: {self.saldo}"
    

    def __str__(self):

        return f"Nombre: {self.nombre} Email: {self.email} saldo: {self.saldo}"
    
    def __int__(self):

        return f"saldo: {self.saldo}"
    
    def insertar(self):

        """
        Almacena un nuevo cliente
        """
        
        query = f"INSERT INTO clientes (name, email, saldo) VALUES(%s,%s,%s)"
        var = (self.nombre,self.email,self.saldo)

        cursor.execute(query,var)
        conn.commit() 


    def Actualizar(self):

        """
        Actualiza los datos de un cliente
        """

        if not self.nombre or not self.email or not self.saldo:

            raise ValueError("Papi no hay cliente")
        
        query = f"UPDATE clientes SET name=%s, email=%s, saldo=%s WHERE email=%s"

        hug = (self.nombre, self.email, self.saldo, self.email)

        cursor.execute(query,hug)
        conn.commit()
    
    @staticmethod
    def obtener_uno(email):

        """
        Devuelve una tupla de cliente por su email
        """
        
        query = f"SELECT * FROM clientes WHERE email = %s"

        var = (email,)  #la coma al final python declara la tupla 

        cursor.execute(query,var)

        variable = cursor.fetchone()

        return Cliente(variable[0],variable[1],variable[2])
    
    @staticmethod
    def obtener_todo():

        """
        Devuelve todos los clientes en una lista de tuplas
        """

        query = f"SELECT * FROM clientes"

        cursor.execute(query,)
        
        clientes = cursor.fetchall()

        list = []

        for cliente in clientes:

            dato = Cliente(cliente[0],cliente[1],cliente[2])
            list.append(dato) 

        return list

    def borrar(email):

        """
        Borrar un cliente con su email
        """

        query = f"DELETE FROM clientes WHERE email = %s"

        var = (email,)  

        cursor.execute(query,var)
        conn.commit() 