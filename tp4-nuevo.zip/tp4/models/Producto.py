from config.database import cursor,conn

class Producto:

    def __init__(self,nombre,precio, stock = 0, cod_prod = 0):

        if not nombre:

            raise Exception("[ERROR] El producto tiene que tener un nombre")
        
        if not precio:

            raise Exception("[ERROR] El producto tiene que tener un precio")
        
        self.cod_prod = cod_prod
        self.nombre = nombre
        self.precio = precio
        self.stock = stock

    def insertar(self):

        """
        Ingresa un nuevo prodcuto
        """

        if not self.nombre or not self.precio:

            raise ValueError("Papi no hay Producto")
        
        query = f"INSERT INTO productos (cod_prod, nombre, precio, stock) VALUES (%s, %s, %s, %s)"

        var = (self.cod_prod, self.nombre, self.precio, self.stock)

        cursor.execute(query, var)
        conn.commit()

    def actualizar(self):

        """
        Actualiza los datos del producto
        """
        
        query = f"UPDATE productos SET nombre = %s, precio = %s, stock = %s WHERE cod_prod = %s"

        hug = (self.nombre,self.precio, self.stock,self.cod_prod)

        cursor.execute(query,hug)
        conn.commit()

    @staticmethod
    def obtener(cod_prod):
            
        """
        Devuelve una instancia desde la bd con el codigo producto
        """

        query = f"SELECT * FROM productos WHERE cod_prod = %s"

        var = (cod_prod,)  #la coma al final python declara la tupla 

        cursor.execute(query,var)

        variable = cursor.fetchone()

        return Producto(variable[1],variable[2],variable[3],variable[0])
    
    def obtener_todo():

        """
        Devuelve una lista de tuplas con todos los productos
        """

        query = f"SELECT * FROM productos"

        cursor.execute(query,)
        
        productos = cursor.fetchall()

        list = []

        for producto in productos:

            dato = Producto(producto[1],producto[2],producto[3],producto[0])
            list.append(dato) 

        return list


    def __repr__(self):

        return f"Nombre: {self.nombre} Precio: {self.precio} stock: {self.stock}"
    

    def __str__(self) -> str:
    
        return f"Nombre: {self.nombre} Precio: {self.precio}"